"use client"

import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Zap, Sun, Moon } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"
import Link from "next/link"

export function Navigation() {
  const { isDarkMode, toggleTheme } = useTheme()

  return (
    <nav
      className={`sticky top-0 z-50 backdrop-blur-xl transition-all duration-300 ${
        isDarkMode ? "bg-black/80 border-cyan-500/20" : "bg-white/80 border-slate-200/60"
      } border-b`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div
              className={`w-10 h-10 ${
                isDarkMode
                  ? "bg-gradient-to-r from-cyan-500 to-purple-500 shadow-cyan-500/25"
                  : "bg-gradient-to-r from-blue-600 to-indigo-600 shadow-blue-500/20"
              } rounded-xl flex items-center justify-center shadow-lg`}
            >
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">SkillSwapp</span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link
              href="#features"
              className={`${
                isDarkMode ? "text-gray-400 hover:text-cyan-400" : "text-slate-600 hover:text-slate-900"
              } font-medium transition-colors duration-300`}
            >
              Features
            </Link>
            <Link
              href="#how-it-works"
              className={`${
                isDarkMode ? "text-gray-400 hover:text-cyan-400" : "text-slate-600 hover:text-slate-900"
              } font-medium transition-colors duration-300`}
            >
              How it works
            </Link>
            <Link
              href="#pricing"
              className={`${
                isDarkMode ? "text-gray-400 hover:text-cyan-400" : "text-slate-600 hover:text-slate-900"
              } font-medium transition-colors duration-300`}
            >
              Pricing
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            {/* Theme Toggle */}
            <div className="flex items-center space-x-2">
              <Sun className={`w-4 h-4 ${isDarkMode ? "text-gray-400" : "text-yellow-500"}`} />
              <Switch
                checked={isDarkMode}
                onCheckedChange={toggleTheme}
                className={`${
                  isDarkMode
                    ? "data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-cyan-500 data-[state=checked]:to-purple-500"
                    : "data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-blue-500 data-[state=checked]:to-purple-500"
                }`}
              />
              <Moon className={`w-4 h-4 ${isDarkMode ? "text-cyan-400" : "text-gray-400"}`} />
            </div>

            <Link href="/discover">
              <Button
                variant="ghost"
                className={`${
                  isDarkMode
                    ? "text-gray-400 hover:text-cyan-400 hover:bg-cyan-500/10"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                } font-medium transition-all duration-300`}
              >
                Discover
              </Button>
            </Link>

            <Link href="/profile">
              <Button
                variant="ghost"
                className={`${
                  isDarkMode
                    ? "text-gray-400 hover:text-cyan-400 hover:bg-cyan-500/10"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                } font-medium transition-all duration-300`}
              >
                Profile
              </Button>
            </Link>

            <Link href="/dashboard">
              <Button
                variant="ghost"
                className={`${
                  isDarkMode
                    ? "text-gray-400 hover:text-cyan-400 hover:bg-cyan-500/10"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                } font-medium transition-all duration-300`}
              >
                Dashboard
              </Button>
            </Link>

            <Button
              className={`${
                isDarkMode
                  ? "bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 shadow-cyan-500/25"
                  : "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-blue-500/20"
              } text-white font-semibold px-6 shadow-lg hover:shadow-xl transition-all duration-300`}
            >
              Get Started
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
