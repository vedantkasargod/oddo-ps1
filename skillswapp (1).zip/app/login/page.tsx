"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Zap, Mail, Lock, Eye, EyeOff, Sun, Moon } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle("dark")
  }

  return (
    <div
      className={`min-h-screen flex items-center justify-center transition-all duration-500 ${
        isDarkMode ? "bg-black" : "bg-gradient-to-br from-slate-50 via-white to-blue-50"
      } px-4 relative overflow-hidden`}
    >
      {/* Background Effects */}
      <div className="fixed inset-0 opacity-20">
        <div
          className={`absolute inset-0 ${
            isDarkMode
              ? "bg-gradient-to-br from-cyan-500/10 via-transparent to-purple-500/10"
              : "bg-gradient-to-br from-blue-400/20 via-transparent to-indigo-400/20"
          }`}
        />
      </div>

      {/* Floating Neon Elements */}
      {isDarkMode && (
        <div className="fixed inset-0 pointer-events-none">
          <div
            className="absolute w-32 h-32 rounded-full opacity-20 animate-pulse"
            style={{
              left: "10%",
              top: "20%",
              background: "radial-gradient(circle, rgba(6, 182, 212, 0.3) 0%, transparent 70%)",
              filter: "blur(20px)",
              animationDuration: "4s",
            }}
          />
          <div
            className="absolute w-24 h-24 rounded-full opacity-30 animate-pulse"
            style={{
              right: "15%",
              bottom: "30%",
              background: "radial-gradient(circle, rgba(168, 85, 247, 0.3) 0%, transparent 70%)",
              filter: "blur(15px)",
              animationDuration: "3s",
              animationDelay: "1s",
            }}
          />
        </div>
      )}

      <div className="relative w-full max-w-md">
        {/* Theme Toggle */}
        <div className="absolute top-4 right-4 flex items-center space-x-2">
          <Sun className={`w-4 h-4 ${isDarkMode ? "text-gray-400" : "text-yellow-500"}`} />
          <Switch
            checked={isDarkMode}
            onCheckedChange={toggleTheme}
            className={`${
              isDarkMode
                ? "data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-cyan-500 data-[state=checked]:to-purple-500"
                : "data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-blue-500 data-[state=checked]:to-purple-500"
            }`}
          />
          <Moon className={`w-4 h-4 ${isDarkMode ? "text-cyan-400" : "text-gray-400"}`} />
        </div>

        <Card
          className={`${
            isDarkMode
              ? "bg-gray-900/80 border-cyan-500/20 backdrop-blur-xl"
              : "bg-white/90 border-slate-200 backdrop-blur-xl"
          } shadow-2xl`}
          style={{
            boxShadow: isDarkMode ? "0 0 50px rgba(6, 182, 212, 0.1)" : "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
          }}
        >
          <CardHeader className="text-center space-y-4">
            <div className="flex justify-center">
              <div
                className={`w-16 h-16 ${
                  isDarkMode
                    ? "bg-gradient-to-r from-cyan-500 to-purple-500 shadow-cyan-500/25"
                    : "bg-gradient-to-r from-blue-600 to-indigo-600 shadow-blue-500/20"
                } rounded-2xl flex items-center justify-center shadow-lg`}
              >
                <Zap className="w-8 h-8 text-white" />
              </div>
            </div>
            <div>
              <CardTitle className={`text-2xl font-bold ${isDarkMode ? "text-white" : "text-gray-900"}`}>
                Welcome back
              </CardTitle>
              <CardDescription className={`${isDarkMode ? "text-gray-400" : "text-slate-600"}`}>
                Sign in to your SkillSwapp account
              </CardDescription>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <form className="space-y-4">
              <div className="space-y-2">
                <label className={`text-sm font-medium ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>Email</label>
                <div className="relative">
                  <Mail
                    className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 ${
                      isDarkMode ? "text-cyan-400" : "text-gray-500"
                    }`}
                  />
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`pl-10 h-12 ${
                      isDarkMode
                        ? "bg-gray-800/50 border-cyan-500/20 text-white placeholder-gray-500 focus:border-cyan-500 focus:ring-cyan-500/20"
                        : "bg-white border-slate-300 text-slate-900 placeholder-slate-500 focus:border-blue-500 focus:ring-blue-500/20"
                    } transition-all duration-300`}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className={`text-sm font-medium ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                  Password
                </label>
                <div className="relative">
                  <Lock
                    className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 ${
                      isDarkMode ? "text-cyan-400" : "text-gray-500"
                    }`}
                  />
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={`pl-10 pr-10 h-12 ${
                      isDarkMode
                        ? "bg-gray-800/50 border-cyan-500/20 text-white placeholder-gray-500 focus:border-cyan-500 focus:ring-cyan-500/20"
                        : "bg-white border-slate-300 text-slate-900 placeholder-slate-500 focus:border-blue-500 focus:ring-blue-500/20"
                    } transition-all duration-300`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${
                      isDarkMode ? "text-cyan-400 hover:text-cyan-300" : "text-gray-500 hover:text-gray-700"
                    } transition-colors duration-200`}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="remember"
                    className={`w-4 h-4 ${
                      isDarkMode
                        ? "text-cyan-600 bg-gray-800 border-cyan-500 focus:ring-cyan-500"
                        : "text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500"
                    } rounded`}
                  />
                  <label htmlFor="remember" className={`text-sm ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    Remember me
                  </label>
                </div>
                <Link
                  href="/forgot-password"
                  className={`text-sm ${
                    isDarkMode ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-500"
                  } transition-colors duration-200`}
                >
                  Forgot password?
                </Link>
              </div>

              <Button
                className={`w-full h-12 ${
                  isDarkMode
                    ? "bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 shadow-cyan-500/25"
                    : "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-blue-500/20"
                } text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300`}
              >
                Sign In
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className={`w-full border-t ${isDarkMode ? "border-gray-700" : "border-slate-200"}`} />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className={`px-2 ${isDarkMode ? "bg-gray-900 text-gray-400" : "bg-white text-slate-500"}`}>
                  Or continue with
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button
                variant="outline"
                className={`h-12 ${
                  isDarkMode
                    ? "border-cyan-500/20 text-cyan-300 hover:bg-cyan-500/10 hover:border-cyan-500/40"
                    : "border-slate-300 text-slate-700 hover:bg-slate-50"
                } transition-all duration-300`}
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Google
              </Button>
              <Button
                variant="outline"
                className={`h-12 ${
                  isDarkMode
                    ? "border-cyan-500/20 text-cyan-300 hover:bg-cyan-500/10 hover:border-cyan-500/40"
                    : "border-slate-300 text-slate-700 hover:bg-slate-50"
                } transition-all duration-300`}
              >
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                Facebook
              </Button>
            </div>

            <div className="text-center">
              <span className={`text-sm ${isDarkMode ? "text-gray-400" : "text-slate-600"}`}>
                Don't have an account?{" "}
                <Link
                  href="/signup"
                  className={`${
                    isDarkMode ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-500"
                  } font-medium transition-colors duration-200`}
                >
                  Sign up
                </Link>
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
